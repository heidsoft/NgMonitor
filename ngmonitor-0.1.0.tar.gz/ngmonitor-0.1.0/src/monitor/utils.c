#include <stdio.h>
#include "utils.h"
void test1(){
	printf("test 1");
}

void test2(){
	printf("test 2");
}
