#include <stdlib.h>

int main(void) {
	puts("Hello NgDeamon"); /* prints Hello NgDeamon */
	return EXIT_SUCCESS;
}
